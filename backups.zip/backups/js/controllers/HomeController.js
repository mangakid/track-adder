app.controller('HomeController', ['$scope', '$http', function($scope, $http) {

  $scope.searchField= "";
  $scope.typeOfSearch = "artist";
  $scope.nameOrTitle = "name";
  $scope.artistMatches = [];
  $scope.artistTracks = [];
  $scope.playlistName = "Klanks Playlist";
  $scope.artistNames = [];

  var apiKey = "B0XQRNNNPGYJ70WNI";
  var matchedWordCount = 0;
  var currentMatch = "";
  var lastMatch = "";
  var nextString = "";
  var lastString = "";
  var splitSearch = [];
  var httpCallCount = 0;
  var lastHttpCall = "";
  var lastResultsSearch = "";
  var nextStringIndex = 0;
  $scope.regexedText = "";

   $scope.selected = function() {
    var count = 0;
    angular.forEach($scope.artistMatches,
      function(word) {
        count += word.checked ? 1 : 0;
      });
    return count;
  };

    $scope.searchFor = function(){
      startSearch();
    }

    function startSearch(){
      matchedWordCount = 0;
      currentMatch = "";
      lastMatch = "";
      nextString = "";
      lastString = "";
      httpCallCount = 0;
      lastHttpCall = "";
      lastResultsSearch = "";
      window.sessionStorage.clear();
      window.sessionStorage.setItem("artists", JSON.stringify($scope.artistMatches));
      window.sessionStorage.setItem("playlistName", $scope.playlistName);
      $scope.artistMatches = [];
      var filteredSearchField = $scope.searchField.replace(/[\s\W\s+]/gi,' ');
      filteredSearchField = filteredSearchField.replace(/\s\s+/g, ' ');
      $scope.searchedWords = [];
      splitSearch = filteredSearchField.split(" "); //Make an array of the search items
      if(splitSearch.length > 1){
        nextString = splitSearch[1];                //Next string assigned
        nextStringIndex = 1;                        //Next sting index assigned
      }
      spotifyArtistSearch(splitSearch[0]);
      //httpSearch(splitSearch[0]);
    }

    function spotifyArtistSearch(searchString){
      if(searchString != "" && searchString != null/* && httpCallCount < 150 && $scope.searchedWords.indexOf(searchString) === -1 && countMatchedWords() <= splitSearch.length*/){
        $scope.searchedWords.push(searchString);
        lastHttpCall = searchString;
        console.log("Making spotify http call with "+ searchString + ", httpcall count = "+ httpCallCount);
        $http.get('https://api.spotify.com/v1/search?q=' + encodeURIComponent(searchString) +'&type=artist&limit=50')
         .success(function(data){
           httpCallCount += 1;
           console.log("spotify search success");
           $scope.artistData = data.artists.items;
           $scope.artistData.sort(function(a,b) {return (a.popularity > b.popularity) ? -1 : ((b.popularity > a.popularity) ? 1 : 0);} );

           if($scope.artistData[0] != undefined){
            var spotifyBestMatch = $scope.artistData[0];
            spotifyBestMatch.checked = false;
            if(artistAlreadyAdded(spotifyBestMatch) == false){
              $scope.artistMatches.push(spotifyBestMatch);
            }
           }


           if($scope.artistData.length > 0 /*&& JSON.stringify($scope.artistData).toLowerCase().indexOf(searchString.toLowerCase()) > -1*/){ //If results found
             //console.log("Results found");
             searchResultsForMatch(searchString);
           }

           else{
             updateMatchedWords();
             console.log("No http results found so matched words updated from httpSearch()");
             var indexOfSearchString = splitSearch.indexOf(searchString);

             if(indexOfSearchString != -1){ //If searchstring was just one word

               if(nextString != "" /*&& httpCallCount < 150*/){   //and httpsearch again with next string
                 console.log("calling http with next string, httpcount = " + httpCallCount);
                 searchString = nextString;
                 nextString = splitSearch[nextStringIndex +1]; //Make next string, next string in split search array       //Next string assigned
                 nextStringIndex += 1;

                 /*
                 while($scope.searchedWords.indexOf(searchString) > -1 && nextString != ""){
                 searchString = nextString;
                 nextString = splitSearch[nextStringIndex +1]; //Make next string, next string in split search array       //Next string assigned
                 nextStringIndex += 1;
                 }
                 */
                 
                 spotifyArtistSearch(searchString);
               }
             }

              //Search string was more than one word and last string has not been httpSearched
             else if(lastString != ""/* && httpCallCount < 150*/ && $scope.searchedWords.indexOf(lastString) === -1){   //httpsearch again with last word in searchString
                 console.log("httpcall with lastString: " + lastString + ", nextString = "+ nextString);
                 spotifyArtistSearch(lastString);
               }
               //Search string was more than one word, but last string has been httpsearched already httpsearch with next string
             else if(nextString != ""){
                searchString = nextString;
                nextString = splitSearch[nextStringIndex +1]; //Make next string, next string in split search array       //Next string assigned
                nextStringIndex += 1;
                spotifyArtistSearch(searchString);
             }
           }
         })
         .error(function(err) {
            httpCallCount += 1;

             console.log("Error: "+ JSON.stringify(err));
         });
     }
     else if($scope.artistMatches != null){
        if(currentMatch != lastMatch){
          currentMatch = lastMatch;
        }
        updateMatchedWords();
        //getTracks();
        //console.log($scope.artistTracks);
     }
    }

    
    function searchResultsForMatch(searchString){
      console.log("searching results for match with: " + searchString);
      currentMatch = getMatch(searchString);

      console.log("Last Match was: "+ lastMatch.name +", current match = "+ currentMatch.name);

      if(currentMatch != "" && currentMatch != null){                             //matchfound
        console.log("last match was " + lastMatch.name + ", current match is: "+ currentMatch.name );
        lastMatch = currentMatch;
        var newSearch = addNextWord(searchString);
        if(newSearch != searchString){                                            //If next string available search again
          lastResultsSearch = searchString;                                       //LastResultsSearch assigned
          console.log("searching again with next word: "+ newSearch);
          searchResultsForMatch(newSearch);
        }
        else{
          if(lastHttpCall != searchString){
            //httpSearch(searchString);
            console.log("lasthttpcall != searchString so Making http call with: " + searchString);
            
            spotifyArtistSearch(searchString);
          }
          else{
            console.log("Last http call === searchString so updating matched words");
            updateMatchedWords();
          }
        }
      }
      else{ //No match found so httpSearch
        console.log("No match found in internal search");
        if(lastHttpCall != lastResultsSearch && $scope.searchedWords.indexOf(lastHttpCall) === -1){
          console.log("Calling http with lastResultsSearch: "+ lastResultsSearch);
          nextString = lastString;                                                 //Next string assigned
          nextStringIndex += -1;                                                   //Next string index assigned
          //lastString = splitSearch[nextStringIndex -1]

          spotifyArtistSearch(lastResultsSearch);
          //httpSearch(lastResultsSearch);
        }
        else if($scope.searchedWords.indexOf(searchString) === -1){
          console.log("calling http with searchString: "+ searchString);
          spotifyArtistSearch(searchString);
          //httpSearch(searchString);
        }
        else if(nextString != ""/* && httpCallCount < 150*/){   //and httpsearch again with next string
           console.log("calling http with next string, httpcount= " + httpCallCount);
           searchString = nextString;
           nextString = splitSearch[nextStringIndex +1]; //Make next string, next string in split search array       //Next string assigned
           nextStringIndex += 1;                                                                                     //Next string index assigned -- (NEW)
           spotifyArtistSearch(searchString);
         }
      }
    }
    
    function countMatchedWords(){
      var count = 0;
      if ($scope.artistMatches.length === null){
        return count;
      }
      for(i=0;i < $scope.artistMatches.length;i++){
        count += $scope.artistMatches[i].name.split(" ").length;
      }
      return count;
    }

    
    function getMatch(searchString){
      var exactCount = 0;
      var partialCount = 0;
      var matchFound = false;
      var match = "";
      console.log("in getMatch");

      while(matchFound === false && exactCount < $scope.artistData.length){ //Look for exact match
        var name = $scope.artistData[exactCount].name.toLowerCase();
        if(searchString.toLowerCase() === name){
          console.log("Exact match found: "+ searchString + " = " + $scope.artistData[exactCount].name);
          match = $scope.artistData[exactCount];
          match.checked= true;
          matchFound = true;
        }
        exactCount += 1;
      }

      
      while(matchFound === false && partialCount < $scope.artistData.length){ //Look for partial match

        var name = $scope.artistData[partialCount].name.toLowerCase();
        matchFound = findStringInString(searchString.toLowerCase(),name);
  
        if (matchFound){
          match = $scope.artistData[partialCount];
          match.checked = false;
          console.log("Partial match found: "+ match.name);
        }

        partialCount += 1;
      }

      return match;
    }

    function artistAlreadyAdded(anArtist){
      var artistAdded = false;
      for(var i = 0; i < $scope.artistMatches.length; i++){
        if($scope.artistMatches[i].name == anArtist.name){
          return true;
        }
      }
      return artistAdded;
    }

    function updateMatchedWords(){
      if(artistAlreadyAdded(lastMatch) == false){
        console.log("Updating artistMatches: "+ lastMatch.name);
        //lastMatch.checked=true;

        $scope.artistMatches.push(lastMatch);
      }
    }

    function addNextWord(searchString){
      var newSearch = "";
      console.log("addNextWord: creating next searchString");
      lastString = nextString;
      console.log("addNextWord: Next string is: "+ nextString);
      if(nextString != null && nextString != ""){
        newSearch = searchString.concat(" ",nextString);
        console.log("addNextWord: New search string is: " + newSearch);
      }
      else{
        var newSearch = searchString;
        console.log("No next string, so newSearch: "+ newSearch);
      }
      nextString = splitSearch[nextStringIndex + 1];              //Next string assigned
      nextStringIndex += 1;                                       //Next sting index assigned
      return newSearch;
    }

    function findStringInString(string1,string2)
    {
      var match = false;
      if(string2.indexOf(string1) > -1)
      {
        match = true;
      }
      return match;
    }

    function makeArrayOfArtistNames(artists){
      $scope.artistNames = [];
      for(i = 0; i <artists.length; i++){
        $scope.artistNames.push(artists[i].name);
      }
    }

    function generateRandomString(length) {
      var text = '';
      var possible = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';

      for (var i = 0; i < length; i++) {
        text += possible.charAt(Math.floor(Math.random() * possible.length));
      }
      return text;
    };

    $scope.logIn = function() {

      //Check to see that at least one artist has been selected
      var atLeastOneChecked = false;

      for(var i = 0; i< $scope.artistMatches.length;i++){
        if($scope.artistMatches[i].checked == true){
          atLeastOneChecked = true;
          break;
        }
      }

      if(atLeastOneChecked == true){
        var checkedArtists = [];
        for(var i = 0; i < $scope.artistMatches.length; i++){
          if($scope.artistMatches[i].checked){
            checkedArtists.push($scope.artistMatches[i]);
          }
        }


        window.sessionStorage.setItem("artists", JSON.stringify(checkedArtists));
        window.sessionStorage.setItem("playlistName", $scope.playlistName);


        var redirect_uri = window.location + "callback.html" ; // Your redirect uri
        //var redirect_uri = "http://www.mangakid.co.uk/callback.html";
        var state = generateRandomString(16);
        var client_id = '0bee6ff652604932b638745971c452c7';
        var stateKey = 'spotify_auth_state';

        console.log("current location = " + window.location);
        console.log("state = "+ state);

        window.sessionStorage.setItem(stateKey, state);

        var scope = 'user-read-private playlist-modify-private playlist-modify-public';
        
        var url = 'https://accounts.spotify.com/authorize';
        url += '?response_type=token';
        url += '&client_id=' + encodeURIComponent(client_id);
        url += '&scope=' + encodeURIComponent(scope);
        url += '&redirect_uri=' + encodeURIComponent(redirect_uri);
        url += '&state=' + encodeURIComponent(state);

        window.open(url);
      }
      else{
        alert("You must select at least one artist.");
      }
    }
}]);