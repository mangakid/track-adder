app.controller('PlaylistController',['$scope', '$http', function($scope, $http){
	//$scope.artistMatches = [];
	$scope.artistMatches = [];
  $scope.artistMatches = JSON.parse(window.sessionStorage.getItem("artists"));
	$scope.artistTracks = [];
	$scope.userId = "";
  $scope.tracksCount = 0;
  var numberOfTracks = 1;
  var trackUris = "";
  var newPlaylistName = window.sessionStorage.getItem("playlistName");
  var playlist_Id = "";

	function getTracks(){
		//$scope.artistMatches = JSON.parse(localStorage.getItem("artists"));
      //var tracksFound = [];
      if($scope.artistMatches.length >= 100){ //Select how many tracks are generated for each artist
        numberOfTracks = 1;
      }else if($scope.artistMatches.length <= 9){
        numberOfTracks = 10;
      }
      else{
        numberOfTracks = Math.floor((100/$scope.artistMatches.length));
      }
      console.log("number of tracks = " + numberOfTracks);
      for(var i = 0; i < $scope.artistMatches.length; i++){
        if($scope.artistMatches[i].checked === true){
          httpTrackSearch($scope.artistMatches[i].id);
          //tracksFound[i] = {name: $scope.artistMatches[i].name, tracks : JSON.stringify(topTracks)};
          //console.log("Artist = " + tracksFound[i].name + " Tracks = " + tracksFound[i].tracks);
        }
      }
    }

    function httpTrackSearch(artistId){
      $http.get('https://api.spotify.com/v1/artists/'+ artistId +'/top-tracks?country=ES')
         .success(function(data){
          //console.log("httpTrackSearch success: " + JSON.stringify(data));
          var processedData = processRawTracksData(data);
          $scope.artistTracks.push(processedData);
          //return processedData;
         })
         .error(function(err) {
            console.log("Error: "+ JSON.stringify(err));
            return err;
         });
    }

    function processRawTracksData(data){
      var newTracks = [];
      var tempNumberOfTracks = numberOfTracks;
      if(numberOfTracks > data.tracks.length){
        tempNumberOfTracks = data.tracks.length;
      }
      for(var i = 0; i < tempNumberOfTracks; i++){
        if($scope.tracksCount < 93){
          var newTrack = {artist:"",title:"",spotifyId:""};
          newTrack.title = data.tracks[i].name;
          newTrack.spotifyId = data.tracks[i].uri;
          newTrack.artist = data.tracks[i].artists[0].name;
          newTracks.push(newTrack);
          $scope.tracksCount += 1;
          trackUris += (data.tracks[i].uri + ",");
          //console.log("NewTracks["+ i +"] = "+ JSON.stringify(newTracks[i]));
        }
      }
      return newTracks;
    }

	function getHashParams() {
      var hashParams = {};
      var e, 
          r = /([^&;=]+)=?([^&;]*)/g,
          q = window.location.hash.substring(1);

      while ( e = r.exec(q)) {
         hashParams[e[1]] = decodeURIComponent(e[2]);
      }
      console.log(hashParams);
      return hashParams;
    };

    var params = getHashParams();

    
    
    var stateKey = 'spotify_auth_state';

    var access_token = params.access_token,
        state = params.state,
        storedState = window.sessionStorage.getItem(stateKey);

    function getUserId(){
    	if(access_token && (state === null || state != storedState)){
    		alert('There was an error during the authentication')
        console.log("access_token = " + access_token + " state = " + state + " stored state = " + storedState);
    	}
    	else{/*
    		window.sessionStorage.removeItem(stateKey);
        window.sessionStorage.removeItem("playlistName");
        window.sessionStorage.removeItem("artists");*/
    		$http({
    				method: "get",
    				url: 'https://api.spotify.com/v1/me',
    				headers: {'Authorization': 'Bearer '+ access_token}})
    		.success(function(data){
    			$scope.userId = data.id;
    			makePlaylist();
    		})
    		.error(function(err){
    			console.log(JSON.stringify(err));
    		});
    	}
    }

    function makePlaylist(){
      $http({
          method: "POST",
          url: 'https://api.spotify.com/v1/users/' + $scope.userId + '/playlists',
          headers: {
              'Authorization' : 'Bearer ' + access_token,
              'Content-Type' : 'application/json'},
          data: '{\"name\":\"'+ newPlaylistName + '\", \"public\":true}'}).
          success(function (response) {
              playlist_Id = response.id;
              addTrackToPlaylist();
          }).
          error(function (response) {
              console.log("failed: " + JSON.stringify(response));
          })
        }

    //playlist_Id
    function addTrackToPlaylist(){
      playlist_Id = encodeURIComponent(playlist_Id);
      trackUris = trackUris.substring(0, trackUris.length - 1);

      console.log("trackUris = " + trackUris);
      $http({
        method: "POST",
        url: 'https://api.spotify.com/v1/users/'+ $scope.userId +'/playlists/'+ playlist_Id +'/tracks?uris='+ encodeURIComponent(trackUris),
        headers: {
            'Authorization' : 'Bearer ' + access_token,
            'Accept' : 'application/json'}})
        .success(function (response) {
            console.log("success! :" + JSON.stringify(response));
        })
        .error(function (response) {
            console.log("failed: " + JSON.stringify(response));

        })
    }

    $scope.openPlaylist = function(){
      var url =  'spotify:user:'+ $scope.userId+':playlist:'+playlist_Id;
      window.location.href= url;
    }

    getTracks();
    getUserId();

}]);