var app = angular.module("OutboxApp",[]);
